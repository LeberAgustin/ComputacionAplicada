#!/bin/bash

esLaborable() {
# Declaracion de variables
	local fecha=$1
	local diaSemana=$(date -d "$fecha" +%u)
	local diaMes=$(date -d "$fecha" +%d)
	local mes=$(date -d "$fecha" +%m)
	local feriadosArchivo="feriados"
	local feriadosMoviblesArchivo="feriadosMovibles"
	esFinDeSemana=false
	esFeriado=false

# Comprobar si es fin de semana
	if [ $diaSemana -eq 6 ] || [ $diaSemana -eq 7 ];then
		echo "La fecha $fecha es un fin de semana"
		esFinDeSemana=true
	fi

# Comprobar si es un feriado inamovible
	if grep -q "$mes-$diaMes" "$feriadosArchivo";then
		# Recorta el motivo del archivo de feriados
		motivo=$(grep "$mes-$diaMes" "$feriadosArchivo" | cut -d':' -f 2)
		echo "La fecha $fecha es un feriado: $motivo"
		esFeriado=true

# Calcula los feriados movibles si es que no era un feriado inamovible
	# Si es en el mes de agosto
	elif [ "$mes" -eq 8 ];then
		if [ "$diaSemana" -eq 1 ] && [ $((($diaMes - 1) / 7 + 1)) -eq 3 ];then
			# Recorta el motivo del archivo feriadosMovibles
			motivo=$(grep "08-17" "$feriadosMoviblesArchivo" | cut -d':' -f 2)
			echo "La fecha $fecha es el feriado movible del 17 de agosto: $motivo"
			esFeriado=true
		fi
	# Si es en el mes de octubre
 	elif [ "$mes" -eq 10 ];then
		if [ "$diaSemana" -eq 1 ] && [ $((($diaMes - 1) / 7 + 1)) -eq 2 ];then
			# Recorta el motivo del archivo feriadosMovibles
			motivo=$(grep "10-12" "$feriadosMoviblesArchivo" | cut -d':' -f 2)
			echo "La fecha $fecha es el feriado movible del 12 de octubre: $motivo"
			esFeriado=true
		fi
	# Si es en el mes de noviembre
	elif [ "$mes" -eq 11 ];then
		if [ "$diaSemana" -eq 1 ] && [ $((($diaMes - 1) / 7 + 1)) -eq 4 ];then
			# Recorta el motivo del archivo feriadosMovibles
			motivo=$(grep "11-20" "$feriadosMoviblesArchivo" | cut -d':' -f 2)
			echo "La fecha $fecha es el feriado movible del 20 de noviembre:$motivo"
			esFeriado=true
		fi
	fi

# Si es un fin de semana o feriado
	if [ "$esFinDeSemana" = true ] || [ "$esFeriado" = true ];then
		echo "No es un dia laborable"
		return 0
	else
		echo "La fecha $fecha es un dia laborable"
		return 1
	fi
}
