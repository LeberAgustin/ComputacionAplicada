#!/bin/bash
# Declaracion de variables
hora=$(date "+%H:%M:%S")
dia=$(date "+%Y%m%d")
directorio_origen="$1"
directorio_destino="$2"

# Funcion para registrar en log
log() {
	echo "$dia - $hora - $1 | $2" >> /var/log/backup_full.log
}

# Enviar log por mail
enviar_log() {
	mutt -s "Log de respaldo" root < /var/log/backup_full.log
}

# Hacer respaldo
hacer_backup() {
	nombre_backup="$(basename "$directorio_origen")_bkp_$dia.tar.gz"
# Si el directorio existe y esta montado:
	if [ -d "$directorio_origen" ] || mountpoint -q "$directorio_origen" ; then
		tar -czf"$directorio_destino/$nombre_backup" -C "$directorio_origen" .
		log "Respaldo de $directorio_origen" "Exito"
# Si no existe
	else
		log "Directorio $directorio_origen no encontrado o montado" "Error"
	fi
}

# Opcion de ayuda
while getopts "h" option; do
	case $option in
# Si ingresa h muestra la ayuda
	h)
		echo "Uso: $0 directorio_origen directorio_destino"
		exit
		;;
# Si ingresa otro argumento
	\?)
		echo "Opcion no valida: -$OPTARG"
		exit 1
	esac
done

# Si no ingresa argumento
if [ "$#" -ne 2 ]; then
	echo "Uso: $0 directorio_origen directorio_destino"
	exit 1
fi

# Verificar si directorio de destino existe y esta montado
if [ ! -d "$directorio_destino" ] || ! mountpoint -q "$directorio_destino"; then
	log "El directorio de destino $destino no existe o no esta montado" "Error"
	enviar_log
	exit 1
fi

# Hacer respaldo
hacer_backup "$directorio_origen" "$directorio_destino"

# Envia log por mail a root
enviar_log
