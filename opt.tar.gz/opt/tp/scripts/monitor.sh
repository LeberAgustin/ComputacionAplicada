#!/bin/bash

# Comprobar si el proceso esta en ejecucion
if pgrep -x "$1" > /dev/null; then
	# El proceso si esta en ejecucion
	exit
# Si el proceso no esta en ejecucion
else
	# Envia mail a root informando
	echo "El proceso "$1" no esta en ejecucion actualmente" | mail -s "Alerta de proceso no en ejecucion" root
fi
