#!/bin/bash

# Incluimos el archivo esLaborable.sh
source esLaborable.sh

# Fecha por argumento
fecha="$1"

# Verifica si la fecha dada esta de forma correcta
while [ -z "$fecha" ] || ! [[ "$fecha" =~ ^[0-9]{4}-[0-1]{1}[0-9]{1}-[0-3]{1}[0-9]{1} ]] ;do
	echo "POr favor escriba una fecha en el formato 'YYYY-MM-DD' como argumento"
	read -p "fecha (YYYY-MM-DD): " fecha
done

# Llama a la funcion de esLaborable con la fecha pasada por argumento
esLaborable "$fecha"
